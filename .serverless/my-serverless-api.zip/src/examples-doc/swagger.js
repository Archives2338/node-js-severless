/**
 * @openapi
  * components:
 *   schemas:
 *     StarWarsPeople:
 *       type: object
 *       properties:

 *         nombre:
 *           type: string
 *           example: Jesus
 *         altura:
 *           type: string
 *           example: 1.72

**/
